import time
import csv
import os
import sys
import psutil

from src.matrix.matrix import NaiveMatrix
from src.matrix.matrix_numpy import MatrixNumPy
from src.matrix.matrix_numba import MatrixNumba
from src.matrix.matrix_multiprocessing import MatrixMultiprocessing
from src.matrix.utils import generate_matrices_numpy

def get_process_memory_mb():
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / (1024 * 1024)

def run_benchmark(algorithm_name, make_matrices, multiply_func, sizes, runs, writer):
    print(f"\nBenchmarking: {algorithm_name}")

    if "Numba" in algorithm_name:
        A_warm, B_warm = generate_matrices_numpy(10)
        A_obj, B_obj = make_matrices(A_warm, B_warm)
        _ = multiply_func(A_obj, B_obj)
    
    for n in sizes:
        print(f"  Size {n}x{n}...", end=" ", flush=True)

        times = []
        mems = []

        for r in range(1, runs + 1):
            A_np, B_np = generate_matrices_numpy(n)
            A, B = make_matrices(A_np, B_np)

            mem_before = get_process_memory_mb()
            start = time.perf_counter()
            _ = multiply_func(A, B)
            end = time.perf_counter()
            mem_after = get_process_memory_mb()

            t = end - start
            m = max(mem_before, mem_after)

            times.append(t)
            mems.append(m)

            writer.writerow([algorithm_name, n, r, t, m])

        avg_t = sum(times) / len(times)
        avg_m = sum(mems) / len(mems)
        print(f"avg time = {avg_t:.4f}s, avg mem = {avg_m/1024:.2f}GB")

def main(output_folder, sizes, runs):
    os.makedirs(output_folder, exist_ok=True)
    output_csv = os.path.join(output_folder, "dense_algorithms.csv")

    algorithms = [
        ("Naive-Standard",
         lambda A, B: (NaiveMatrix(A.tolist()), NaiveMatrix(B.tolist())),
         lambda A, B: A.multiply_standard(B)),
        ("Naive-Tiled",
         lambda A, B: (NaiveMatrix(A.tolist()), NaiveMatrix(B.tolist())),
         lambda A, B: A.multiply_tiled(B, 64)),

        ("NumPy-Standard",
         lambda A, B: (MatrixNumPy(A), MatrixNumPy(B)),
         lambda A, B: A.multiply_standard(B)),
        ("NumPy-Tiled",
         lambda A, B: (MatrixNumPy(A), MatrixNumPy(B)),
         lambda A, B: A.multiply_tiled(B, 64)),

        ("Numba-Standard",
         lambda A, B: (MatrixNumba(A), MatrixNumba(B)),
         lambda A, B: A.multiply_standard(B)),
        ("Numba-Parallel",
         lambda A, B: (MatrixNumba(A), MatrixNumba(B)),
         lambda A, B: A.multiply_standard_parallel(B)),
        ("Numba-Tiled",
         lambda A, B: (MatrixNumba(A), MatrixNumba(B)),
         lambda A, B: A.multiply_tiled(B, 64)),
        ("Numba-Tiled-Parallel",
         lambda A, B: (MatrixNumba(A), MatrixNumba(B)),
         lambda A, B: A.multiply_tiled_parallel(B, 64)),

        ("MP-Standard",
         lambda A, B: (MatrixMultiprocessing(A), MatrixMultiprocessing(B)),
         lambda A, B: A.multiply_standard(B)),
        ("MP-Tiled",
         lambda A, B: (MatrixMultiprocessing(A), MatrixMultiprocessing(B)),
         lambda A, B: A.multiply_tiled(B, 64)),
    ]

    with open(output_csv, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Algorithm", "Size", "Run", "TimeSeconds", "MemoryMB"])

        for name, make_mats, func in algorithms:
            run_benchmark(name, make_mats, func, sizes, runs, writer)

    print(f"\nResults saved to {output_csv}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python benchmark_dense.py <output_folder>")
        sys.exit(1)

    output_folder = sys.argv[1]
    sizes = [32, 64, 128, 256, 512, 1024, 2048]
    runs = 3

    print("Running full benchmark...")
    main(output_folder, sizes, runs)

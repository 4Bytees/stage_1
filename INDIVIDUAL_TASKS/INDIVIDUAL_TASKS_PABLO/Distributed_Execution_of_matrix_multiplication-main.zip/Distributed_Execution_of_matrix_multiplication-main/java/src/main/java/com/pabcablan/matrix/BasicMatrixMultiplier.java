package com.pabcablan.matrix;

public class BasicMatrixMultiplier {

    public static double[][] multiply(double[][] A, double[][] B) {
        int n = A.length;
        double[][] result = new double[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    result[i][j] += A[i][k] * B[k][j];
                }
            }
        }
        return result;
    }

    public static double[][] multiplyTiled(double[][] A, double[][] B, int blockSize) {
        int n = A.length;
        double[][] result = new double[n][n];

        for (int iBlock = 0; iBlock < n; iBlock += blockSize) {
            for (int jBlock = 0; jBlock < n; jBlock += blockSize) {
                for (int kBlock = 0; kBlock < n; kBlock += blockSize) {

                    int iLimit = Math.min(iBlock + blockSize, n);
                    int jLimit = Math.min(jBlock + blockSize, n);
                    int kLimit = Math.min(kBlock + blockSize, n);

                    for (int i = iBlock; i < iLimit; i++) {
                        for (int j = jBlock; j < jLimit; j++) {
                            for (int k = kBlock; k < kLimit; k++) {
                                result[i][j] += A[i][k] * B[k][j];
                            }
                        }
                    }
                }
            }
        }
        return result;
    }
}
from src.benchmark.benchmark import run_bench

if __name__ == "__main__":
    run_bench(sizes=[32, 64, 128, 256, 512, 1024, 2048], runs=3, threads=4, block_size=128, output_csv="results/distributed_benchmark_python.csv")
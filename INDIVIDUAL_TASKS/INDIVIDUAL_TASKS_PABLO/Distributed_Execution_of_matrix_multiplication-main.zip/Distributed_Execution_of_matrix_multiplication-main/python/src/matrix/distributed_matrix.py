from multiprocessing import Pool
import pickle
from collections import defaultdict
import random

class DistributedMatrix:
    """
    Implements distributed (multiprocess-based) matrix multiplication:
    - MapReduce/block-wise ('tiled') version: divide and distribute by submatrices (blocks).
    - Row-wise version: assign each result row to a different worker (easy baseline).
    """

    def __init__(self, data):
        self.data = data
        self.shape = (len(data), len(data[0]) if data else 0)

    @classmethod
    def random(cls, n):
        data = [[random.random() for _ in range(n)] for _ in range(n)]
        return cls(data)

    @staticmethod
    def _map_block(args):
        row_offset, col_offset, A_block, B_block = args
        partials = []

        n_rows = len(A_block)
        n_cols = len(B_block[0])

        for i in range(n_rows):
            row_result = []
            for j in range(n_cols):
                s = sum(A_block[i][k] * B_block[k][j] for k in range(len(B_block)))
                row_result.append(s)
            serialized = pickle.dumps((row_offset + i, col_offset, row_result))
            partials.append(pickle.loads(serialized))

        return partials

    def multiply_mapreduce(self, other, num_workers=4, block_size=8, block_size_cols=8):
        n = self.shape[0]
        blocks = []
        for i in range(0, n, block_size):
            A_block = self.data[i:i + block_size]
            for j in range(0, n, block_size_cols):
                B_block = [row[j:j + block_size_cols] for row in other.data]
                blocks.append((i, j, A_block, B_block))

        with Pool(processes=num_workers) as pool:
            mapped_results = pool.map(DistributedMatrix._map_block, blocks)

        partial_results = defaultdict(list)
        for block_partials in mapped_results:
            for row_idx, col_offset, partial_row in block_partials:
                partial_results[row_idx].append((col_offset, partial_row))

        final_data = []
        for row_idx in range(n):
            row_blocks = sorted(partial_results[row_idx], key=lambda x: x[0])
            full_row = []
            for _, part in row_blocks:
                full_row.extend(part)
            final_data.append(full_row)

        return DistributedMatrix(final_data)

    @staticmethod
    def _multiply_row(args):
        row_idx, A_row, B = args
        n = len(B[0])
        result_row = []
        for j in range(n):
            s = sum(A_row[k] * B[k][j] for k in range(len(B)))
            result_row.append(s)
        return (row_idx, result_row)

    def multiply_rowwise(self, other, num_workers=4):
        args = [(i, self.data[i], other.data) for i in range(self.shape[0])]
        with Pool(processes=num_workers) as pool:
            results = pool.map(DistributedMatrix._multiply_row, args)
        results.sort()
        data = [row for idx, row in results]
        return DistributedMatrix(data)

import os
import pandas as pd
import numpy as np

RESULTS_JAVA = os.path.join("..", "results", "distributed_benchmark_java.csv")
RESULTS_PYTHON = os.path.join("..", "results", "distributed_benchmark_python.csv")

def read_benchmark_csv(path, platform):
    df = pd.read_csv(path)
    df['Platform'] = platform
    return df

def avg_by(df, cols_mean, group_keys):
    return df.groupby(group_keys, as_index=False)[cols_mean].mean()

def print_df(df, title):
    print("\n"+"="*len(title))
    print(title)
    print("="*len(title))
    print(df.to_string(index=False))
    print()

def main():
    java = read_benchmark_csv(RESULTS_JAVA, "Java")
    python = read_benchmark_csv(RESULTS_PYTHON, "Python")
    full = pd.concat([java, python], axis=0, ignore_index=True)

    max_n = int(full["MatrixSize"].max())
    summary = avg_by(
        full[full["MatrixSize"]==max_n],
        ["TimeSeconds","MemoryMB","Speedup","Efficiency"], 
        ["Platform","Algorithm"]
    )
    summary = summary.sort_values(by=["TimeSeconds"])
    print_df(summary, f"Summary at Maximum Matrix Size (N={max_n}): Time, Memory, Speedup, Efficiency")
    best_time = summary.loc[summary["TimeSeconds"].idxmin()]
    best_mem = summary.loc[summary["MemoryMB"].idxmin()]
    best_eff = summary.loc[summary["Efficiency"].idxmax()]
    print(f"* Fastest overall: {best_time['Algorithm']} ({best_time['Platform']}), {best_time['TimeSeconds']:.3g} s")
    print(f"* Lowest memory peak: {best_mem['Algorithm']} ({best_mem['Platform']}), {best_mem['MemoryMB']:.1f} MB")
    print(f"* Best efficiency: {best_eff['Algorithm']} ({best_eff['Platform']}), {best_eff['Efficiency']:.2f}")
    print("-" * 50)

    java_n = java[java["MatrixSize"]==max_n]
    python_n = python[python["MatrixSize"]==max_n]
    common_algos = sorted(list(set(java_n["Algorithm"]).intersection(set(python_n["Algorithm"]))))
    comp_rows = []
    for alg in common_algos:
        j = java_n[java_n["Algorithm"]==alg]
        p = python_n[python_n["Algorithm"]==alg]
        row = {
            "Algorithm": alg,
            "Time_Java(s)": j["TimeSeconds"].mean() if not j.empty else np.nan,
            "Time_Python(s)": p["TimeSeconds"].mean() if not p.empty else np.nan,
            "Mem_Java(MB)": j["MemoryMB"].mean() if not j.empty else np.nan,
            "Mem_Python(MB)": p["MemoryMB"].mean() if not p.empty else np.nan,
            "Speedup_Java": j["Speedup"].mean() if not j.empty else np.nan,
            "Speedup_Python": p["Speedup"].mean() if not p.empty else np.nan,
        }
        comp_rows.append(row)
    table_compare = pd.DataFrame(comp_rows)
    print_df(table_compare, f"Java vs Python Comparison at N={max_n} (Algorithms in Both)")
    print("-" * 50)

    distrib = summary[summary["Algorithm"].str.contains("Distributed")]
    distrib = distrib.sort_values("TimeSeconds")
    print_df(distrib, "Distributed Algorithms Summary (Scalability Focus)")
    fastest_distributed = distrib.iloc[0]
    print(f"* Fastest distributed: {fastest_distributed['Algorithm']} ({fastest_distributed['Platform']}), {fastest_distributed['TimeSeconds']:.3g} s")
    print("-" * 50)

    if 'NetworkOverhead_s' in java.columns and not java[java['Algorithm'].str.contains('Distributed')].empty:
        network = avg_by(
            java[(java["MatrixSize"]==max_n) & (java["Algorithm"].str.contains("Distributed"))],
            ["NetworkOverhead_s","DataTransferred_MB","TransferRate_MBps"],
            ["Algorithm"]
        )
        summary_for_network = summary.set_index('Algorithm')
        time_match = summary_for_network.loc[network['Algorithm']]['TimeSeconds'].values
        if len(time_match) == len(network['NetworkOverhead_s']):
            network['NetOverhead/Time'] = (network['NetworkOverhead_s'] / time_match)
        print_df(network, f"Network Overhead and Data Transfer (Distributed, Java, N={max_n})")
        if not network.empty:
            highest_data = network.loc[network["DataTransferred_MB"].idxmax()]
            print(f"* Most data transferred: {highest_data['Algorithm']}, {highest_data['DataTransferred_MB']:.2f} MB")
    else:
        print("No Network Overhead / Data Transfer Data available for Distributed Java.")
    print("-" * 50)

    summary['%_over_best'] = (summary['TimeSeconds']/summary['TimeSeconds'].min()*100).round(1)
    ranking_table = summary[['Platform','Algorithm','TimeSeconds','%_over_best']].sort_values('TimeSeconds')
    print_df(ranking_table, f"Ranking Algorithms by Time (Relative to Fastest, %) at N={max_n}")

    print("\nTop-3 Fastest Algorithms at N={}:".format(max_n))
    print(summary.nsmallest(3, "TimeSeconds")[["Platform","Algorithm","TimeSeconds"]].to_string(index=False))

    print("\nTop-3 Lowest-Memory Algorithms at N={}:".format(max_n))
    print(summary.nsmallest(3, "MemoryMB")[["Platform","Algorithm","MemoryMB"]].to_string(index=False))
    print("-" * 50)

    min_n = int(full['MatrixSize'].min())
    speedup_min = avg_by(full[full['MatrixSize']==min_n],["Speedup"],["Platform","Algorithm"]).set_index(["Platform","Algorithm"])
    speedup_max = avg_by(full[full['MatrixSize']==max_n],["Speedup"],["Platform","Algorithm"]).set_index(["Platform","Algorithm"])
    delta_speedup = (speedup_max["Speedup"] - speedup_min["Speedup"]).sort_values(ascending=False)
    print("\nGreatest Speedup Improvement (N={} vs N={}):".format(min_n, max_n))
    print(delta_speedup.head(5).to_string())
    print("-" * 50)

if __name__ == "__main__":
    print("Benchmark analysis summary\n")
    main()
package com.pabcablan.model;

public class BenchmarkCase {
    public String algName;
    public Runnable func;
    public int threads;
    public int blockSize;

    public BenchmarkCase(String algName, Runnable func, int threads, int blockSize) {
        this.algName = algName;
        this.func = func;
        this.threads = threads;
        this.blockSize = blockSize;
    }
}
import unittest
from src.matrix.matrix import NaiveMatrix
from python.src.utils.utils import generate_matrices

class TestNaiveMatrix(unittest.TestCase):

    def setUp(self):
        self.A = NaiveMatrix([[1, 2], [3, 4]])
        self.B = NaiveMatrix([[5, 6], [7, 8]])
        self.expected_data = [[19, 22], [43, 50]]

    def test_multiply_standard(self):
        result = self.A.multiply_standard(self.B)
        self.assertEqual(result.data, self.expected_data)

    def test_multiply_tiled_various_block_sizes(self):
        for block_size in [1, 2, 4, 32]:
            with self.subTest(block_size=block_size):
                result = self.A.multiply_tiled(self.B, block_size)
                self.assertEqual(result.data, self.expected_data)

    def test_algorithms_equivalence_random(self):
        A_list, B_list = generate_matrices(8)
        A = NaiveMatrix(A_list)
        B = NaiveMatrix(B_list)

        C_std = A.multiply_standard(B)
        C_tiled = A.multiply_tiled(B)

        for i in range(8):
            for j in range(8):
                self.assertAlmostEqual(C_std.data[i][j],C_tiled.data[i][j])

    def test_random_shape(self):
        A = NaiveMatrix.random(10)
        B = NaiveMatrix.random(10)
        C = A.multiply_standard(B)
        self.assertEqual(C.shape, (10, 10))


if __name__ == '__main__':
    unittest.main(verbosity=2)
import numpy as np


class MatrixNumPy:
    
    def __init__(self, data):
        self.data = np.array(data, dtype=np.float64)
        self.shape = self.data.shape
    
    @classmethod
    def random(cls, n):
        return cls(np.random.rand(n, n).astype(np.float64))
    
    def multiply_standard(self, other):
        C = self.data @ other.data
        return MatrixNumPy(C)
    
    def multiply_tiled(self, other, block_size=32):
        n = self.data.shape[0]
        C = np.zeros((n, n))
        
        for i_block in range(0, n, block_size):
            for j_block in range(0, n, block_size):
                for k_block in range(0, n, block_size):
                    
                    i_limit = min(i_block + block_size, n)
                    j_limit = min(j_block + block_size, n)
                    k_limit = min(k_block + block_size, n)
                    
                    A_block = self.data[i_block:i_limit, k_block:k_limit]
                    B_block = other.data[k_block:k_limit, j_block:j_limit]
                    C[i_block:i_limit, j_block:j_limit] += A_block @ B_block
        
        return MatrixNumPy(C)
package com.pabcablan.task;

import java. io.Serializable;
import java.util.concurrent.Callable;

import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.HazelcastInstanceAware;
import com.hazelcast.map. IMap;

public class RowMultiplyTask implements Callable<double[]>, Serializable, HazelcastInstanceAware {
    
    private static final long serialVersionUID = 1L;
    
    private final double[] rowA;
    private final int rowIndex;
    private transient HazelcastInstance hazelcastInstance;

    public RowMultiplyTask(double[] rowA, int rowIndex) {
        this.rowA = rowA;
        this.rowIndex = rowIndex;
    }

    @Override
    public double[] call() {
        IMap<String, double[][]> matrixMap = hazelcastInstance. getMap("matrix-data");
        double[][] matrixB = matrixMap.get("matrixB");
        
        String nodeId = hazelcastInstance.getCluster().getLocalMember().getUuid().toString().substring(0, 8);
        System.out.println("Node " + nodeId + " processing row " + rowIndex);
        
        int colsB = matrixB[0].length;
        int colsA = rowA.length;
        double[] resultRow = new double[colsB];

        for (int j = 0; j < colsB; j++) {
            for (int k = 0; k < colsA; k++) {
                resultRow[j] += rowA[k] * matrixB[k][j];
            }
        }

        return resultRow;
    }

    @Override
    public void setHazelcastInstance(HazelcastInstance hazelcastInstance) {
        this.hazelcastInstance = hazelcastInstance;
    }
    
    public int getRowIndex() {
        return rowIndex;
    }
}
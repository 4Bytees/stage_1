from multiprocessing import Pool
import random

class ParallelMatrix:
    def __init__(self, data):
        self.data = data
        self.shape = (len(data), len(data[0]) if data else 0)

    @classmethod
    def random(cls, n):
        data = [[random.random() for _ in range(n)] for _ in range(n)]
        return cls(data)

    @staticmethod
    def _compute_row(args):
        row_idx, A_row, B = args
        n = len(B[0])
        result_row = []
        for j in range(n):
            s = sum(A_row[k] * B[k][j] for k in range(len(B)))
            result_row.append(s)
        return (row_idx, result_row)

    @staticmethod
    def _compute_block(args):
        i_block, block_size, A, B = args
        n = len(A)
        i_start = i_block * block_size
        i_end = min(i_start + block_size, n)
        rows = []
        for i in range(i_start, i_end):
            row = []
            for j_block in range(0, n, block_size):
                j_limit = min(j_block + block_size, n)
                for j in range(j_block, j_limit):
                    s = 0.0
                    for k_block in range(0, n, block_size):
                        k_limit = min(k_block + block_size, n)
                        for k in range(k_block, k_limit):
                            s += A[i][k] * B[k][j]
                    row.append(s)
            rows.append(row)
        return (i_start, rows)

    def multiply_parallel(self, other, num_workers=4):
        n = self.shape[0]
        args = [(i, self.data[i], other.data) for i in range(n)]
        with Pool(processes=num_workers) as pool:
            results = pool.map(ParallelMatrix._compute_row, args)
        results.sort()
        data = [row for idx, row in results]
        return ParallelMatrix(data)

    def multiply_tiled_parallel(self, other, num_workers=4, block_size=32):
        n = self.shape[0]
        num_blocks = (n + block_size - 1) // block_size
        args = [(i, block_size, self.data, other.data) for i in range(num_blocks)]

        with Pool(processes=num_workers) as pool:
            results = pool.map(ParallelMatrix._compute_block, args)
        data = [None] * n
        for i_start, block_rows in results:
            for offset, row in enumerate(block_rows):
                data[i_start + offset] = row
        return ParallelMatrix(data)
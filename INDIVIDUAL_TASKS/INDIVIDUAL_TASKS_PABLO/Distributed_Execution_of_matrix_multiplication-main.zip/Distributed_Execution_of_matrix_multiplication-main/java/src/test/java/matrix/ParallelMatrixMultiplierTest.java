package matrix;

import java.util.Random;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

import com.pabcablan.matrix.BasicMatrixMultiplier;
import com.pabcablan.matrix.ParallelMatrixMultiplier;

public class ParallelMatrixMultiplierTest {

    private double[][] A;
    private double[][] B;
    private double[][] expected;

    @Before
    public void setUp() {
        A = new double[][]{{1, 2}, {3, 4}};
        B = new double[][]{{5, 6}, {7, 8}};
        expected = new double[][]{{19, 22}, {43, 50}};
    }

    @Test
    public void testMultiplyParallelRowwise() {
        double[][] result = ParallelMatrixMultiplier.multiply(A, B, 2);
        assertMatrixEquals(expected, result, 1e-10);
    }

    @Test
    public void testMultiplyParallelTiled() {
        double[][] result = ParallelMatrixMultiplier.multiplyTiled(A, B, 2, 1);
        assertMatrixEquals(expected, result, 1e-10);
    }

    @Test
    public void testEquivalenceWithStandardRowwise() {
        int n = 8;
        double[][] dataA = randomMatrix(n, n);
        double[][] dataB = randomMatrix(n, n);

        double[][] C_par = ParallelMatrixMultiplier.multiply(dataA, dataB, 2);
        double[][] C_std = BasicMatrixMultiplier.multiply(dataA, dataB);

        assertMatrixEquals(C_std, C_par, 1e-7);
    }

    @Test
    public void testEquivalenceWithStandardTiled() {
        int n = 8;
        double[][] dataA = randomMatrix(n, n);
        double[][] dataB = randomMatrix(n, n);

        double[][] C_par = ParallelMatrixMultiplier.multiplyTiled(dataA, dataB, 2, 2);
        double[][] C_std = BasicMatrixMultiplier.multiply(dataA, dataB);

        assertMatrixEquals(C_std, C_par, 1e-7);
    }

    private static double[][] randomMatrix(int rows, int cols) {
        Random rand = new Random();
        double[][] mat = new double[rows][cols];
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                mat[i][j] = rand.nextDouble();
        return mat;
    }

    private void assertMatrixEquals(double[][] expected, double[][] actual, double delta) {
        assertEquals(expected.length, actual.length);
        for (int i = 0; i < expected.length; i++) {
            assertEquals(expected[i].length, actual[i].length);
            for (int j = 0; j < expected[i].length; j++) {
                assertEquals(expected[i][j], actual[i][j], delta);
            }
        }
    }
}
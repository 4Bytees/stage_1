package com.pabcablan.matrix;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import com.hazelcast.cluster.Member;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IExecutorService;
import com.hazelcast.map.IMap;
import com. pabcablan.task. BlockMultiplyTask;
import com.pabcablan.task.RowMultiplyTask;

public class DistributedMatrixMultiplier {

    private final HazelcastInstance hazelcast;
    private final IExecutorService executorService;
    private final List<Member> members;
    private int blockSize;
    
    public DistributedMatrixMultiplier(HazelcastInstance hazelcast) {
        this(hazelcast, 256);
    }

    public DistributedMatrixMultiplier(HazelcastInstance hazelcast, int blockSize) {
        this.hazelcast = hazelcast;
        this.executorService = hazelcast.getExecutorService("matrix-executor");
        this.members = new ArrayList<>(hazelcast. getCluster().getMembers());
        this.blockSize = blockSize;
    }

    public double[][] multiply(double[][] A, double[][] B) {
        int rowsA = A.length;
        double[][] result = new double[rowsA][B[0].length];

        IMap<String, double[][]> matrixMap = hazelcast.getMap("matrix-data");
        matrixMap.put("matrixB", B);

        List<Future<double[][]>> futures = new ArrayList<>();
        List<Integer> startRows = new ArrayList<>();

        for (int i = 0; i < rowsA; i += blockSize) {
            int endRow = Math.min(i + blockSize, rowsA);
            int currentBlockSize = endRow - i;

            double[][] blockA = new double[currentBlockSize][];
            for (int j = 0; j < currentBlockSize; j++) {
                blockA[j] = A[i + j];
            }
            
            BlockMultiplyTask task = new BlockMultiplyTask(blockA, i);
            Member targetMember = members.get((i / blockSize) % members.size());
            futures. add(executorService.submitToMember(task, targetMember));
            startRows.add(i);
        }

        for (int i = 0; i < futures.size(); i++) {
            try {
                double[][] resultBlock = futures.get(i).get();
                int startRow = startRows.get(i);
                
                System.arraycopy(resultBlock, 0, result, startRow, resultBlock.length);
                
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("Distributed task interrupted", e);
            } catch (ExecutionException e) {
                throw new RuntimeException("Error executing distributed task", e);
            }
        }

        matrixMap.remove("matrixB");

        return result;
    }

    public double[][] multiplyRowWise(double[][] A, double[][] B) {
        int rowsA = A.length;
        double[][] result = new double[rowsA][B[0].length];
        IMap<String, double[][]> matrixMap = hazelcast.getMap("matrix-data");
        matrixMap.put("matrixB", B);

        List<Future<double[]>> futures = new ArrayList<>();

        for (int i = 0; i < rowsA; i++) {
            RowMultiplyTask task = new RowMultiplyTask(A[i], i);
            Member targetMember = members.get(i % members.size());
            futures.add(executorService.submitToMember(task, targetMember));
        }

        for (int i = 0; i < futures.size(); i++) {
            try {
                result[i] = futures.get(i).get();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("Distributed row-wise task interrupted", e);
            } catch (ExecutionException e) {
                throw new RuntimeException("Error in distributed row-wise multiplication", e);
            }
        }

        matrixMap.remove("matrixB");
        return result;
    }
}
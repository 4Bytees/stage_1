import os
import sys
import multiprocessing
import numpy as np
import matplotlib.pyplot as plt

from src.plot.utils import read_csv_data


def _set_log_x_with_sizes(ax, avg_times):
    sizes = sorted({s for algo in avg_times for s in avg_times[algo]})
    ax.set_xscale("log", base=2)
    ax.set_xticks(sizes)
    ax.set_xticklabels([f"{n}" for n in sizes])
    return sizes


def plot_time_vs_size(avg_times, output_path):
    plt.figure(figsize=(10, 6))
    for algo in sorted(avg_times):
        sizes = sorted(avg_times[algo])
        times = [avg_times[algo][s] for s in sizes]
        plt.plot(sizes, times, marker="o", linewidth=2, markersize=5, label=algo)

    plt.yscale("log")
    ax = plt.gca()
    ax.yaxis.set_minor_locator(plt.NullLocator())
    _set_log_x_with_sizes(ax, avg_times)

    plt.xlabel("Matrix size (n × n)")
    plt.ylabel("Average execution time (s)")
    plt.title("Execution time vs matrix size")
    plt.grid(True, which="major", ls="--", alpha=0.3)
    plt.legend(bbox_to_anchor=(1.02, 1), loc="upper left", fontsize=8)
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_speedup_efficiency(avg_times, output_path):
    num_cores = multiprocessing.cpu_count()
    baseline = avg_times["Naive-Standard"]
    parallel_algos = ["Numba-Parallel", "Numba-Tiled-Parallel", "MP-Standard"]

    plt.figure(figsize=(12, 5))

    ax1 = plt.subplot(1, 2, 1)
    for algo in parallel_algos:
        if algo not in avg_times:
            continue
        sizes = sorted(avg_times[algo])
        sizes_valid, speedups = [], []
        for s in sizes:
            if s in baseline:
                sizes_valid.append(s)
                speedups.append(baseline[s] / avg_times[algo][s])
        if sizes_valid:
            ax1.plot(sizes_valid, speedups, marker="o", linewidth=2, markersize=5, label=algo)

    _set_log_x_with_sizes(ax1, avg_times)
    ax1.set_xlabel("Matrix size (n × n)")
    ax1.set_ylabel("Speedup vs Naive-Standard")
    ax1.set_title("Speedup of parallel implementations")
    ax1.grid(True, alpha=0.3)
    ax1.legend(fontsize=8)

    ax2 = plt.subplot(1, 2, 2)
    for algo in parallel_algos:
        if algo not in avg_times:
            continue
        sizes = sorted(avg_times[algo])
        sizes_valid, effs = [], []
        for s in sizes:
            if s in baseline:
                sp = baseline[s] / avg_times[algo][s]
                sizes_valid.append(s)
                effs.append(sp / num_cores)
        if sizes_valid:
            ax2.plot(sizes_valid, effs, marker="s", linewidth=2, markersize=5, label=algo)

    _set_log_x_with_sizes(ax2, avg_times)
    ax2.set_xlabel("Matrix size (n × n)")
    ax2.set_ylabel("Efficiency (speedup / #cores)")
    ax2.set_title("Parallel efficiency")
    ax2.grid(True, alpha=0.3)
    ax2.legend(fontsize=8)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_bars_large(avg_times, avg_mem, output_path, size_large=2048):
    algos = [a for a in avg_times if size_large in avg_times[a]]
    algos.sort(key=lambda a: avg_times[a][size_large])

    times = [avg_times[a][size_large] for a in algos]
    mems = [avg_mem[a][size_large] for a in algos]
    x = np.arange(len(algos))
    width = 0.35

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

    bars1 = ax1.bar(x, times, width, color="skyblue", edgecolor="navy", alpha=0.85)
    ax1.set_xticks(x)
    ax1.set_xticklabels(algos, rotation=45, ha="right")
    ax1.set_ylabel("Average time (s)")
    ax1.set_title(f"Execution time at n={size_large}")
    ax1.grid(True, axis="y", alpha=0.3)
    for b, t in zip(bars1, times):
        ax1.text(b.get_x() + b.get_width()/2, b.get_height()*1.01,
                 f"{t:.1f}s" if t >= 1 else f"{t:.3f}s",
                 ha="center", va="bottom", fontsize=8)

    bars2 = ax2.bar(x, mems, width, color="lightcoral", edgecolor="darkred", alpha=0.85)
    ax2.set_xticks(x)
    ax2.set_xticklabels(algos, rotation=45, ha="right")
    ax2.set_ylabel("Average memory (MB)")
    ax2.set_title(f"Memory usage at n={size_large}")
    ax2.grid(True, axis="y", alpha=0.3)
    for b, m in zip(bars2, mems):
        ax2.text(b.get_x() + b.get_width()/2, b.get_height()*1.01, f"{m:.0f}MB", ha="center", va="bottom", fontsize=8)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_vectorized_vs_numba(avg_times, output_path):
    selected = ["NumPy-Standard", "NumPy-Tiled", "Numba-Standard", "Numba-Tiled-Parallel"]

    plt.figure(figsize=(8, 5))
    for algo in selected:
        if algo not in avg_times:
            continue
        sizes = sorted(avg_times[algo])
        times = [avg_times[algo][s] for s in sizes]
        plt.plot(sizes, times, marker="o", linewidth=2, markersize=5, label=algo)

    plt.yscale("log")
    ax = plt.gca()
    ax.yaxis.set_minor_locator(plt.NullLocator())
    _set_log_x_with_sizes(ax, avg_times)

    plt.xlabel("Matrix size (n × n)")
    plt.ylabel("Average execution time (s)")
    plt.title("Vectorized (NumPy) vs JIT (Numba)")
    plt.grid(True, which="major", ls="--", alpha=0.3)
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()


def main(csv_path, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    avg_times, avg_mem = read_csv_data(csv_path)

    plot_time_vs_size(avg_times, os.path.join(output_dir, "fig1_time_vs_size.png"))
    plot_speedup_efficiency(avg_times, os.path.join(output_dir, "fig2_speedup_efficiency.png"))
    plot_bars_large(avg_times, avg_mem, os.path.join(output_dir, "fig3_bars_n2048.png"))
    plot_vectorized_vs_numba(avg_times, os.path.join(output_dir, "fig4_numpy_numba.png"))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: py -m src.benchmark.plot_paper sv_path> <output_dir>")
        sys.exit(1)

    main(sys.argv[1], sys.argv[2])

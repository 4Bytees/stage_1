import unittest
from src.matrix.distributed_matrix import DistributedMatrix
from src.matrix.matrix import NaiveMatrix
import random
class TestDistributedMatrix(unittest.TestCase):
    def setUp(self):
        self.A = DistributedMatrix([[1, 2], [3, 4]])
        self.B = DistributedMatrix([[5, 6], [7, 8]])
        self.expected_data = [[19, 22], [43, 50]]

    def test_multiply_mapreduce(self):
        result = self.A.multiply_mapreduce(self.B, num_workers=2, block_size=1)
        self.assertEqual(result.data, self.expected_data)

    def test_multiply_rowwise(self):
        result = self.A.multiply_rowwise(self.B, num_workers=2)
        self.assertEqual(result.data, self.expected_data)

    def test_equivalence_with_standard_mapreduce(self):
        n = 8
        dataA = [[random.random() for _ in range(n)] for _ in range(n)]
        dataB = [[random.random() for _ in range(n)] for _ in range(n)]
        da = DistributedMatrix(dataA)
        db = DistributedMatrix(dataB)
        na = NaiveMatrix(dataA)
        nb = NaiveMatrix(dataB)
        C_dist = da.multiply_mapreduce(db, num_workers=2, block_size=2)
        C_std = na.multiply_standard(nb)
        for i in range(n):
            for j in range(n):
                self.assertAlmostEqual(C_dist.data[i][j], C_std.data[i][j], places=7)

    def test_equivalence_with_standard_rowwise(self):
        n = 8
        dataA = [[random.random() for _ in range(n)] for _ in range(n)]
        dataB = [[random.random() for _ in range(n)] for _ in range(n)]
        da = DistributedMatrix(dataA)
        db = DistributedMatrix(dataB)
        na = NaiveMatrix(dataA)
        nb = NaiveMatrix(dataB)
        C_dist = da.multiply_rowwise(db, num_workers=2)
        C_std = na.multiply_standard(nb)
        for i in range(n):
            for j in range(n):
                self.assertAlmostEqual(C_dist.data[i][j], C_std.data[i][j], places=7)

if __name__ == '__main__':
    unittest.main(verbosity=2)
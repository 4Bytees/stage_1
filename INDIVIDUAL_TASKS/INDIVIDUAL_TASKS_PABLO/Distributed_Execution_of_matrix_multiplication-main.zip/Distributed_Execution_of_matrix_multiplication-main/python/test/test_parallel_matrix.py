import unittest
import random
from src.matrix.parallel_matrix import ParallelMatrix
from src.matrix.matrix import NaiveMatrix

class TestParallelMatrix(unittest.TestCase):
    def setUp(self):
        self.A = ParallelMatrix([[1, 2], [3, 4]])
        self.B = ParallelMatrix([[5, 6], [7, 8]])
        self.expected_data = [[19, 22], [43, 50]]

    def test_multiply_parallel_rowwise(self):
        result = self.A.multiply_parallel(self.B, num_workers=2)
        self.assertEqual(result.data, self.expected_data)

    def test_multiply_parallel_tiled(self):
        result = self.A.multiply_tiled_parallel(self.B, num_workers=2, block_size=1)
        self.assertEqual(result.data, self.expected_data)

    def test_equivalence_with_standard_rowwise(self):
        n = 8
        dataA = [[random.random() for _ in range(n)] for _ in range(n)]
        dataB = [[random.random() for _ in range(n)] for _ in range(n)]
        pa = ParallelMatrix(dataA)
        pb = ParallelMatrix(dataB)
        na = NaiveMatrix(dataA)
        nb = NaiveMatrix(dataB)
        C_par = pa.multiply_parallel(pb, num_workers=2)
        C_std = na.multiply_standard(nb)
        for i in range(n):
            for j in range(n):
                self.assertAlmostEqual(C_par.data[i][j], C_std.data[i][j], places=7)

    def test_equivalence_with_standard_tiled(self):
        n = 8
        dataA = [[random.random() for _ in range(n)] for _ in range(n)]
        dataB = [[random.random() for _ in range(n)] for _ in range(n)]
        pa = ParallelMatrix(dataA)
        pb = ParallelMatrix(dataB)
        na = NaiveMatrix(dataA)
        nb = NaiveMatrix(dataB)
        C_par = pa.multiply_tiled_parallel(pb, num_workers=2, block_size=2)
        C_std = na.multiply_standard(nb)
        for i in range(n):
            for j in range(n):
                self.assertAlmostEqual(C_par.data[i][j], C_std.data[i][j], places=7)

if __name__ == '__main__':
    unittest.main(verbosity=2)
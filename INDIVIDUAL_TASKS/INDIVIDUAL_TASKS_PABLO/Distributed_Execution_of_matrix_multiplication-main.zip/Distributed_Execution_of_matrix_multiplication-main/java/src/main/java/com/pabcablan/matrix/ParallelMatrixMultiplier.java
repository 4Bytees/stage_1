package com.pabcablan.matrix;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ParallelMatrixMultiplier {

    public static double[][] multiply(double[][] A, double[][] B, int numThreads) {
        int size = A.length;
        double[][] result = new double[size][B[0].length];

        ExecutorService executorService = Executors.newFixedThreadPool(numThreads);

        for (int i = 0; i < size; i++) {
            final int row = i;
            executorService.submit(() -> multiplyRow(A, B, result, row));
        }

        executorService.shutdown();

        try {
            executorService.awaitTermination(1, TimeUnit.HOURS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Matrix multiplication interrupted", e);
        }
        return result;
    }

    private static void multiplyRow(double[][] A, double[][] B, double[][] result, int row) {
        int colsB = B[0].length;
        int colsA = A[0].length;

        for (int j = 0; j < colsB; j++) {
            for (int k = 0; k < colsA; k++) {
                result[row][j] += A[row][k] * B[k][j];
            }
        }
    }

    public static double[][] multiplyTiled(double[][] A, double[][] B, int numThreads, int blockSize) {
        int n = A.length;
        double[][] result = new double[n][B[0].length];

        ExecutorService executor = Executors.newFixedThreadPool(numThreads);

        for (int iBlock = 0; iBlock < n; iBlock += blockSize) {
            final int startRow = iBlock;
            final int iLimit = Math.min(iBlock + blockSize, n);

            executor.submit(() -> {
                for (int i = startRow; i < iLimit; i++) {
                    for (int jBlock = 0; jBlock < n; jBlock += blockSize) {
                        int jLimit = Math.min(jBlock + blockSize, n);
                        for (int kBlock = 0; kBlock < n; kBlock += blockSize) {
                            int kLimit = Math.min(kBlock + blockSize, n);
                            for (int j = jBlock; j < jLimit; j++) {
                                double sum = 0;
                                for (int k = kBlock; k < kLimit; k++) {
                                    sum += A[i][k] * B[k][j];
                                }
                                result[i][j] += sum;
                            }
                        }
                    }
                }
            });
        }

        executor.shutdown();

        try {
            executor.awaitTermination(1, TimeUnit.HOURS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Matrix multiplication interrupted", e);
        }
        return result;
    }
}
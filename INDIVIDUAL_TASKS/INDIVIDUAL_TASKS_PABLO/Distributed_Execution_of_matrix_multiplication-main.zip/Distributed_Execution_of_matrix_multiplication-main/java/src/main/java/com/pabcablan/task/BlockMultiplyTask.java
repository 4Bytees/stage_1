package com.pabcablan.task;

import java.io. Serializable;
import java.util.concurrent. Callable;

import com.hazelcast. core.HazelcastInstance;
import com.hazelcast.core.HazelcastInstanceAware;
import com.hazelcast.map. IMap;

public class BlockMultiplyTask implements Callable<double[][]>, Serializable, HazelcastInstanceAware {
    
    private static final long serialVersionUID = 1L;
    
    private final double[][] rowsA;
    private final int startRow;
    private transient HazelcastInstance hazelcastInstance;

    public BlockMultiplyTask(double[][] rowsA, int startRow) {
        this.rowsA = rowsA;
        this.startRow = startRow;
    }

    @Override
    public double[][] call() {
        IMap<String, double[][]> matrixMap = hazelcastInstance.getMap("matrix-data");
        double[][] matrixB = matrixMap.get("matrixB");
        
        String nodeId = hazelcastInstance.getCluster().getLocalMember().getUuid().toString().substring(0, 8);
        System.out.println("Node " + nodeId + " processing rows " + startRow + "-" + (startRow + rowsA.length - 1));
        
        int numRows = rowsA.length;
        int colsB = matrixB[0].length;
        int colsA = rowsA[0].length;
        double[][] resultBlock = new double[numRows][colsB];

        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < colsB; j++) {
                for (int k = 0; k < colsA; k++) {
                    resultBlock[i][j] += rowsA[i][k] * matrixB[k][j];
                }
            }
        }

        return resultBlock;
    }

    @Override
    public void setHazelcastInstance(HazelcastInstance hazelcastInstance) {
        this.hazelcastInstance = hazelcastInstance;
    }
    
    public int getStartRow() {
        return startRow;
    }
}
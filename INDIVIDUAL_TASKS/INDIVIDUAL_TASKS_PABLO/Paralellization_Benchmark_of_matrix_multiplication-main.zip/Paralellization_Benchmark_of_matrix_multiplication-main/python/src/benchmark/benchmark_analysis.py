import csv
import multiprocessing
import statistics
from collections import defaultdict
import sys


def analyze_results(csv_path):
    data = defaultdict(list)

    with open(csv_path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            algo = row["Algorithm"]
            size = int(row["Size"])
            t = float(row["TimeSeconds"])
            data[(algo, size)].append(t)

    avg_time = {
        (algo, size): statistics.mean(times)
        for (algo, size), times in data.items()
    }

    num_cores = multiprocessing.cpu_count()

    print("\nSPEEDUP AND EFFICIENCY (vs Naive-Standard)\n")
    print(f"Logical cores (cpu_count): {num_cores}")

    algorithms = sorted({algo for (algo, _) in avg_time.keys()})
    sizes = sorted({size for (_, size) in avg_time.keys()})

    parallel_algos = {
        "Numba-Parallel",
        "Numba-Tiled-Parallel",
        "MP-Standard",
        "MP-Tiled",
    }

    for size in sizes:
        print(f"\nSize: {size}x{size}")
        print("-" * 70)
        t_baseline = avg_time[("Naive-Standard", size)]
        print(f"Baseline Naive-Standard: {t_baseline:.6f}s")

        for algo in algorithms:
            if algo == "Naive-Standard":
                continue
            t_algo = avg_time[(algo, size)]
            speedup = t_baseline / t_algo
            if algo in parallel_algos:
                efficiency = speedup / num_cores
                print(f"{algo:22s}  t={t_algo:8.6f}s  "
                      f"speedup={speedup:6.2f}×  eff={efficiency:5.2f}")
            else:
                print(f"{algo:22s}  t={t_algo:8.6f}s  "
                      f"speedup={speedup:6.2f}×")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python analysis.py sv_path>")
        sys.exit(1)

    csv_path = sys.argv[1]
    analyze_results(csv_path)

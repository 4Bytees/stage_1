import csv
import statistics
from collections import defaultdict

def read_csv_data(csv_path):
    raw_times = defaultdict(list)
    raw_mem = defaultdict(list)

    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            algo = row["Algorithm"]
            size = int(row["Size"])
            t = float(row["TimeSeconds"])
            m = float(row["MemoryMB"])
            raw_times[(algo, size)].append(t)
            raw_mem[(algo, size)].append(m)

    avg_times, avg_mem = defaultdict(dict), defaultdict(dict)
    for (algo, size), times in raw_times.items():
        avg_times[algo][size] = statistics.mean(times)
        avg_mem[algo][size] = statistics.mean(raw_mem[(algo, size)])
    return avg_times, avg_mem

import unittest
import numpy as np
from src.matrix.matrix_numba import MatrixNumba
from src.matrix.utils import generate_matrices_numpy


class TestMatrixNumba(unittest.TestCase):

    def setUp(self):
        self.A = MatrixNumba([[1, 2], [3, 4]])
        self.B = MatrixNumba([[5, 6], [7, 8]])
        self.expected = np.array([[19, 22], [43, 50]])

    def test_multiply_standard(self):
        result = self.A.multiply_standard(self.B)
        np.testing.assert_array_equal(result.data, self.expected)

    def test_multiply_standard_parallel(self):
        result = self.A.multiply_standard_parallel(self.B)
        np.testing.assert_array_equal(result.data, self.expected)

    def test_multiply_tiled_various_block_sizes(self):
        for block_size in [1, 2, 4, 32]:
            with self.subTest(block_size=block_size):
                result = self.A.multiply_tiled(self.B, block_size)
                np.testing.assert_array_equal(result.data, self.expected)

    def test_multiply_tiled_parallel_various_block_sizes(self):
        for block_size in [1, 2, 4, 32]:
            with self.subTest(block_size=block_size):
                result = self.A.multiply_tiled_parallel(self.B, block_size)
                np.testing.assert_array_equal(result.data, self.expected)

    def test_algorithms_equivalence_random(self):
        A_np, B_np = generate_matrices_numpy(8)
        A = MatrixNumba(A_np)
        B = MatrixNumba(B_np)

        C_std = A.multiply_standard(B)
        C_tiled = A.multiply_tiled(B)

        np.testing.assert_allclose(C_std.data, C_tiled.data, rtol=1e-7, atol=1e-7)

    def test_random_shape(self):
        A = MatrixNumba.random(10)
        B = MatrixNumba.random(10)
        C = A.multiply_standard(B)
        self.assertEqual(C.shape, (10, 10))


if __name__ == '__main__':
    unittest.main(verbosity=2)

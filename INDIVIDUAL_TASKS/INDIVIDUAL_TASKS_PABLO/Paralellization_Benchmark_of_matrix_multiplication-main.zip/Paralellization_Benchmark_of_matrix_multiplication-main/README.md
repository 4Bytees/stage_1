# Parallelization Benchmark of Matrix Multiplication

## Introduction

This repository contains a comprehensive benchmarking framework comparing different implementation strategies for matrix multiplication on multicore CPUs. The study evaluates pure Python implementations (Naive, Naive-Tiled) against vectorized libraries (NumPy), JIT-compiled kernels (Numba), and process-based parallelism (Multiprocessing) to guide optimal strategy selection based on performance and resource constraints.

**Key Findings:**
- 🚀 NumPy achieves **15,833× speedup** over naive baseline  
- ⚡ Numba-Tiled-Parallel reaches **952× speedup** with **79.33% parallel efficiency**  
- 🔴 Multiprocessing provides only **2.12× speedup** despite using 12 cores (0.18% efficiency)  
- 💾 Vectorized implementations use **60% less memory** than pure Python  
- 🎯 Thread-based parallelism vastly outperforms process-based approaches

## 🎯 Features

- **Sequential Implementations:**
  - Naive-Standard: Baseline triple-loop algorithm
  - Naive-Tiled: Cache-aware blocking optimization

- **Vectorized Implementations:**
  - NumPy-Standard: Optimized BLAS-backed multiplication
  - NumPy-Tiled: Block-wise NumPy operations

- **JIT-Compiled Implementations:**
  - Numba-Standard: JIT-compiled triple-loop
  - Numba-Tiled: JIT-compiled tiled kernel
  - Numba-Parallel: Thread-based parallelism (`prange`)
  - Numba-Tiled-Parallel: Tiled + multithreading

- **Multiprocessing Implementations:**
  - MP-Standard: Process-based row distribution
  - MP-Tiled: Process-based tiled variant

- **Comprehensive Benchmarking:**
  - Matrix sizes: 32×32 to 2048×2048
  - Metrics: Execution time, speedup, parallel efficiency, memory usage
  - Repetitions: 3 runs per configuration (averaged)

- **Visualization:**
  - 4 publication-ready plots (time, speedup, efficiency, memory)
  - Automated CSV result generation

## 📁 Repository Structure

```
.
├── python/
│   └── src/
│       ├── benchmark/               # Benchmarking framework
│       │   ├── benchmark_runner.py        # Main benchmark driver
│       │   ├── benchmark_analysis.py      # Post-processing & analysis
│       │   └── __init__.py
│       ├── implementations/
│       │   ├── matrix.py                 # Naive implementations
│       │   ├── matrix_numpy.py           # NumPy implementations
│       │   ├── matrix_numba.py           # Numba implementations
│       │   ├── matrix_multiprocessing.py # Multiprocessing implementations
│       │   └── __init__.py
│       ├── plot/
│       │   ├── plot.py                   # Main plotting script
│       │   ├── utils.py                  # Plotting utilities
│       │   └── __init__.py
│       └── __init__.py
├── results/         # CSV benchmark results
│   └── dense_algorithms.csv    # Benchmark data
├── plots/           # Generated visualization
│   ├── fig1_time_vs_size.png      # Overall execution time
│   ├── fig2_speedup_efficiency.png # Speedup & efficiency
│   ├── fig3_bars_n2048.png        # Time & memory at n=2048
│   └── fig4_numpy_numba.png       # Vectorized vs JIT comparison
├── .gitignore
├── LICENSE
└── README.md
```

### 📂 Folder and File Descriptions

#### `python/src/`
- **benchmark/**: Benchmarking framework for running experiments
  - `benchmark_runner.py`: Executes all algorithms across matrix sizes
  - `benchmark_analysis.py`: Aggregates results and computes metrics
- **implementations/**: Algorithm implementations for all strategies
  - `matrix.py`: Pure Python baseline algorithms
  - `matrix_numpy.py`: Vectorized NumPy operations
  - `matrix_numba.py`: JIT-compiled Numba kernels
  - `matrix_multiprocessing.py`: Process-based parallelism
- **plot/**: Visualization and analysis scripts
  - `plot.py`: Main plotting module
  - `utils.py`: Helper functions for figure generation

#### `results/`
- CSV files containing raw and aggregated benchmark results

#### `plots/`
- Publication-ready PNG figures for paper inclusion

## 🛠️ Installation

### Requirements

- **Python 3.12+**
- **Libraries:** NumPy 2.3.5, Numba 0.62.1, Matplotlib 3.10.7, psutil 7.1.3
- **Terminal:** Linux, MacOS, or Windows
- **IDE (recommended):** VS Code, PyCharm

### Setup

1. **Clone the repository:**
    ```bash
    git clone https://github.com/pabcablan/Paralellization_Benchmark_of_matrix_multiplication.git
    cd Paralellization_Benchmark_of_matrix_multiplication
    ```

2. **Create and activate virtual environment:**

    Create virtual environment:
    ```bash
    python -m venv paralellization_bd_venv
    ```

    Activate (Linux/Mac):
    ```bash
    source matmul_venv/bin/activate
    ```
    Activate (Windows):
    ```cmd
    matmul_venv\Scripts\activate
    ```

3. **Install dependencies:**
    ```bash
    pip install numpy==2.3.5 numba==0.62.1 matplotlib==3.10.7 psutil==7.1.3
    ```

## 🚀 Execution

### Run Full Benchmark Suite

```bash
cd python
python -m src.benchmark.benchmark_runner <output_directory>
```

**Example:**
```bash
python -m src.benchmark.benchmark_runner ../results
```

**Output:**
- `<output_directory>/benchmark_results.csv` - Raw timing and memory data
- Console summary with progress indicators

### Post-Process and Analyze Results

```bash
python -m src.benchmark.benchmark_analysis <input_csv>
```
**Example:**
```bash
python -m src.benchmark.benchmark_analysis ../results/benchmark_results.csv
```
**Output:**
- Console summary with key findings

### Generate All Plots

```bash
python -m src.plot.plot <analysis_csv> <output_directory>
```
**Example:**
```bash
python -m src.plot.plot ../results/analysis_results.csv ../plots
```

**Generated Plots:**
1. **fig1_time_vs_size.png** - Execution time across all implementations (log-log scale)
2. **fig2_speedup_efficiency.png** - Speedup and parallel efficiency of parallel implementations
3. **fig3_bars_n2048.png** - Time and memory comparison at largest matrix size
4. **fig4_numpy_numba.png** - Vectorized (NumPy) vs JIT-based (Numba) comparison

## 🎓 Key Results Summary

| **Category**      | **Implementation**       | **Time at n=2048** | **Speedup** | **Efficiency** | **Use Case**                              |
|-------------------|-------------------------|--------------------|-------------|---------------|-------------------------------------------|
| Best Overall      | NumPy-Standard          | 0.0676s            | 15,833×     | —             | Always for dense matrices                 |
| Practical JIT     | Numba-Tiled-Parallel    | 1.1235s            | 952×        | 79.33%        | Custom kernels w/ parallelism             |
| Cache Only        | Naive-Tiled             | 764.7s             | 1.40×       | —             | Pure Python baseline                      |
| Multiprocessing   | MP-Standard             | 504.6s             | 2.12×       | 0.18%         | ❌ Avoid for this workload                 |

**Decision Guide:**
- **Vectorized libraries (NumPy):** Gold standard — **always use when available**
- **JIT-compiled kernels (Numba):** Practical alternative when **custom logic required**
    - Add `prange` for effective **thread-level parallelism**
    - Combine with **tiling** for better cache locality
- **Process-based parallelism:** ❌ **Ineffective** due to high overhead
- **Pure Python:** ❌ **Avoid** — only for educational purposes

## 📊 Performance Characteristics

### Speedup by Matrix Size (Numba-Tiled-Parallel vs Naive-Standard)

| Matrix Size | Speedup  | Efficiency |
|-------------|----------|------------|
| 32×32       | 40.22×   | 3.35%      |
| 128×128     | 214.41×  | 17.87%     |
| 512×512     | 784.59×  | 65.38%     |
| 2048×2048   | **952.02×** | **79.33%** |

### Memory Usage at n=2048

- **NumPy implementations:** ~240–300 MB (most efficient)
- **Numba implementations:** ~270–300 MB
- **Pure Python:** ~630–650 MB (2.7× overhead)
- **Multiprocessing:** ~300–301 MB (per-process overhead)

## 📄 Hardware Configuration

All benchmarks were conducted on:
- **CPU:** AMD Ryzen 5 6600H (12 logical cores)
- **RAM:** 16 GB
- **OS:** Windows 11 Pro 64-bit
- **Python:** 3.12.7

Results may vary on different architectures.

## 🎓 License

This project is licensed under the GNU General Public License v3.0. See [LICENSE](LICENSE) for details.

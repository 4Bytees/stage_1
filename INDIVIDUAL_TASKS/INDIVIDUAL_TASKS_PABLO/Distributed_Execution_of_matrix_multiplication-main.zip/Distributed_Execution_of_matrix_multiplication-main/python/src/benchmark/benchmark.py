import time
import os
import psutil
import math
from src.matrix.matrix import NaiveMatrix
from src.matrix.parallel_matrix import ParallelMatrix
from src.matrix.distributed_matrix import DistributedMatrix

def get_process_memory_mb():
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / (1024 * 1024)

def run_bench(sizes=[64, 128], runs=2, threads=4, block_size=16, output_csv="results/distributed_benchmark_python.csv"):
    os.makedirs(os.path.dirname(output_csv), exist_ok=True)
    with open(output_csv, "w") as f:
        f.write("Algorithm,MatrixSize,Run,Threads,BlockSize,TimeSeconds,MemoryMB,Speedup,Efficiency,PseudoNetworkOverhead_s\n")
        for size in sizes:
            print(f"\n[INFO] === Benchmark for size {size}x{size} ===")
            for run in range(1, runs + 1):
                print(f"[INFO]  Run {run}/{runs}...")

                Adata = [[float(i * j % 7 + 1) for j in range(size)] for i in range(size)]
                Bdata = [[float((i + j) % 5 + 2) for j in range(size)] for i in range(size)]

                bench_cases = [
                    ("Naive-Standard", lambda: NaiveMatrix(Adata).multiply_standard(NaiveMatrix(Bdata)), 1, 0),
                    ("Naive-Tiled", lambda: NaiveMatrix(Adata).multiply_tiled(NaiveMatrix(Bdata), block_size), 1, block_size),
                    ("Parallel-Standard", lambda: ParallelMatrix(Adata).multiply_parallel(ParallelMatrix(Bdata), threads), threads, 0),
                    ("Parallel-Tiled", lambda: ParallelMatrix(Adata).multiply_tiled_parallel(ParallelMatrix(Bdata), threads, block_size), threads, block_size),
                    ("Distributed-Row", lambda: DistributedMatrix(Adata).multiply_rowwise(DistributedMatrix(Bdata), threads), threads, 0),
                    ("Distributed-Tiled", lambda: DistributedMatrix(Adata).multiply_mapreduce(DistributedMatrix(Bdata), threads, block_size), threads, block_size),
                ]

                times = {}
                results = []
                for alg_name, alg_func, n_threads, my_blocksize in bench_cases:
                    print(f"  [INFO]     Algorithm: {alg_name:>16} | Threads: {n_threads} | BlockSize: {my_blocksize}")
                    tmem0 = get_process_memory_mb()
                    t0 = time.perf_counter()
                    _ = alg_func()
                    t1 = time.perf_counter()
                    tmem1 = get_process_memory_mb()
                    delta_time = t1 - t0
                    max_mem = max(tmem0, tmem1)
                    times[alg_name] = delta_time
                    results.append({
                        "Algorithm": alg_name,
                        "MatrixSize": size,
                        "Run": run,
                        "Threads": n_threads,
                        "BlockSize": my_blocksize,
                        "TimeSeconds": delta_time,
                        "MemoryMB": max_mem
                    })
                    print(f"  [RESULT]   {alg_name:>16} | Time: {delta_time:.4f}s | Mem: {max_mem:.2f}MB")
                naive_time = times["Naive-Standard"]
                parallel_time = times["Parallel-Standard"]

                for res in results:
                    alg = res["Algorithm"]
                    my_time = res["TimeSeconds"]
                    res["Speedup"] = naive_time / my_time if my_time > 0 else 0
                    if alg.startswith("Parallel") or alg.startswith("Distributed"):
                        res["Efficiency"] = res["Speedup"] / res["Threads"] if res["Threads"] > 0 else 0
                    else:
                        res["Efficiency"] = 0
                    if alg.startswith("Distributed"):
                        res["PseudoNetworkOverhead_s"] = my_time - parallel_time if my_time > 0 and parallel_time > 0 else 0
                    else:
                        res["PseudoNetworkOverhead_s"] = 0
                    f.write(",".join(str(res[col]) for col in [
                        "Algorithm","MatrixSize","Run","Threads","BlockSize",
                        "TimeSeconds","MemoryMB","Speedup","Efficiency","PseudoNetworkOverhead_s"
                    ]) + "\n")
            print(f"[INFO] === Finished size {size}, all runs ===")
        print(f"\n[INFO] Benchmark finished! Results saved at {output_csv}")
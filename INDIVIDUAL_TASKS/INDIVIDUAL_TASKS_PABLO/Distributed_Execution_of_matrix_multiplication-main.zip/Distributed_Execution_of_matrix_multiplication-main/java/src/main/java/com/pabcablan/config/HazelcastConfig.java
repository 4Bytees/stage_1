package com.pabcablan.config;

import com.hazelcast.config.Config;
import com.hazelcast.config.JoinConfig;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core. HazelcastInstance;

public class HazelcastConfig {

    public static HazelcastInstance initHazelcast(String clusterName) {
        Config config = new Config();
        config.setClusterName(clusterName);
        config.setProperty("hazelcast.initial.min.cluster.size", "4");
        config.getNetworkConfig().setPort(5701);
        config.getNetworkConfig().setPortAutoIncrement(false);

        JoinConfig join = config.getNetworkConfig().getJoin();
        join.getMulticastConfig().setEnabled(false);
        join.getAutoDetectionConfig().setEnabled(false);
        join.getTcpIpConfig()
            .addMember("hazelcast-node1")
            .addMember("hazelcast-node2")
            .addMember("hazelcast-node3")
            .addMember("hazelcast-node4")
            .setEnabled(true);

        return Hazelcast.newHazelcastInstance(config);
    }
}
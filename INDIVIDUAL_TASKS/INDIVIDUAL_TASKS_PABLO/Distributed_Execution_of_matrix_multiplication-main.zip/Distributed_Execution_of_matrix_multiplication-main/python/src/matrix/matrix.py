import random

class NaiveMatrix:
    
    def __init__(self, data):
        self.data = data
        self.shape = (len(data), len(data[0]) if data else 0)

    @classmethod
    def random(cls, n):
        data = [[random.random() for _ in range(n)] for _ in range(n)]
        return cls(data)
 
    def multiply_standard(self, other):
        n = self.shape[0]
        C = [[0] * n for _ in range(n)]
        
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    C[i][j] += self.data[i][k] * other.data[k][j]
        
        return NaiveMatrix(C)
    
    def multiply_tiled(self, other, block_size=32):
        n = self.shape[0]
        C = [[0] * n for _ in range(n)]
        
        for i_block in range(0, n, block_size):
            for j_block in range(0, n, block_size):
                for k_block in range(0, n, block_size):
                    
                    i_limit = min(i_block + block_size, n)
                    j_limit = min(j_block + block_size, n)
                    k_limit = min(k_block + block_size, n)
                    
                    for i in range(i_block, i_limit):
                        for k in range(k_block, k_limit):
                            aik = self.data[i][k]
                            for j in range(j_block, j_limit):
                                C[i][j] += aik * other.data[k][j]
        
        return NaiveMatrix(C)
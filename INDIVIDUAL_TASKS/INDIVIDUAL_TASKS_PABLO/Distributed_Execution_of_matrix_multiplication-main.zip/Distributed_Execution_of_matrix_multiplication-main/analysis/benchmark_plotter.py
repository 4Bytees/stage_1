import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

RESULTS_JAVA = os.path.join("..", "results", "distributed_benchmark_java.csv")
RESULTS_PYTHON = os.path.join("..", "results", "distributed_benchmark_python.csv")
PLOT_DIR = os.path.join("..", "plots")
os.makedirs(PLOT_DIR, exist_ok=True)

def read_benchmark_csv(path, platform):
    df = pd.read_csv(path)
    df['Platform'] = platform
    return df

def avg_by(df, cols_mean, group_keys):
    return df.groupby(group_keys, as_index=False)[cols_mean].mean()

def only_distributed(df):
    return df[df["Algorithm"].str.contains("Distributed")]

def plot_distributed_bars_double(java_df, python_df, metric, filename, ylabel, title_base, ylim=None):
    distributed_algos = ["Distributed-Row", "Distributed-Tiled"]
    ds_java = only_distributed(java_df)
    ds_python = only_distributed(python_df)
    sizes = sorted(set(ds_java["MatrixSize"]).union(set(ds_python["MatrixSize"])))
    nmax = sizes[-1]
    nprev = sizes[-2]
    def get_vals(size, algos):
        vals_java = [avg_by(ds_java[(ds_java['Algorithm'] == alg) & (ds_java['MatrixSize'] == size)], [metric], ['Algorithm'])[metric].mean() for alg in algos]
        vals_python = [avg_by(ds_python[(ds_python['Algorithm'] == alg) & (ds_python['MatrixSize'] == size)], [metric], ['Algorithm'])[metric].mean() for alg in algos]
        return vals_java, vals_python
    fig, axs = plt.subplots(1, 2, figsize=(13, 5), sharey=True)
    for idx, size in enumerate([nprev, nmax]):
        vals_java, vals_python = get_vals(size, distributed_algos)
        x = np.arange(len(distributed_algos))
        width = 0.35
        ax = axs[idx]
        bars_java = ax.bar(x-width/2, vals_java, width, label="Java", color="#2980b9")
        bars_python = ax.bar(x+width/2, vals_python, width, label="Python", color="#e74c3c")
        ax.set_xticks(x)
        ax.set_xticklabels([a.replace("Distributed-","Dist. ") for a in distributed_algos], rotation=30)
        ax.set_title(f"N={size}")
        ax.set_ylabel(ylabel)
        ax.grid(True, axis='y', alpha=0.2)
        ax.set_ylim(bottom=0)
        if ylim:
            ax.set_ylim(ylim)
        for bars, vals in zip([bars_java, bars_python], [vals_java, vals_python]):
            for rect, val in zip(bars, vals):
                if np.isnan(val):
                    ax.annotate('missing', xy=(rect.get_x() + rect.get_width() / 2, 0),
                                xytext=(0, 20), textcoords="offset points",
                                ha='center', va='bottom', fontsize=10, color='gray', fontweight='bold',
                                rotation=75, bbox=dict(boxstyle="round,pad=0.2", fc="#FCFCFC", ec="#DDDDDD"))
    axs[0].legend()
    fig.suptitle(title_base, fontsize=14)
    plt.tight_layout(rect=[0, 0, 1, 0.97])
    plt.savefig(os.path.join(PLOT_DIR, filename), dpi=300)
    plt.close()

def plot_time_vs_size(dfs, filename):
    plt.figure(figsize=(9, 6))
    algo_list = ["Distributed-Row", "Distributed-Tiled",
                 "Naive-Standard", "Naive-Tiled",
                 "Parallel-Standard", "Parallel-Tiled"]
    algo_colors = {
        "Distributed-Row": "#1f77b4",
        "Distributed-Tiled": "#d62728",
        "Naive-Standard": "#2ca02c",
        "Naive-Tiled": "#9467bd",
        "Parallel-Standard": "#ff7f0e",
        "Parallel-Tiled": "#8c564b",
    }
    platform_style = {
        "Java":  {"linestyle": "-",  "marker": "o"},
        "Python":{"linestyle": "--", "marker": "^"}
    }
    for df, platform in dfs:
        pivot = avg_by(df, ['TimeSeconds'], ['Algorithm', 'MatrixSize'])
        for alg in algo_list:
            if alg not in pivot['Algorithm'].unique():
                continue
            vals = pivot[pivot['Algorithm']==alg]
            plt.plot(
                vals['MatrixSize'], vals['TimeSeconds'],
                label=f"{alg.replace('Distributed','Dist.').replace('Parallel','Par.').replace('Naive','Naive')} ({platform})",
                color=algo_colors[alg],
                linestyle=platform_style[platform]["linestyle"],
                marker=platform_style[platform]["marker"],
                linewidth=2, markersize=6, alpha=0.9
            )
    plt.yscale('log')
    plt.xscale('log', base=2)
    plt.xlabel('Matrix size (N x N)')
    plt.ylabel('Time (s, log scale)')
    plt.title('Execution Time vs Matrix Size')
    plt.grid(True, which="both", ls="--", alpha=0.3)
    plt.legend(loc="upper left", fontsize=9, ncol=2)
    plt.tight_layout()
    plt.savefig(os.path.join(PLOT_DIR, filename), dpi=300)
    plt.close()

def plot_memory_vs_size(dfs, filename):
    plt.figure(figsize=(9, 6))
    algo_list = ["Distributed-Row", "Distributed-Tiled",
                 "Naive-Standard", "Naive-Tiled",
                 "Parallel-Standard", "Parallel-Tiled"]
    algo_colors = {
        "Distributed-Row": "#1f77b4",
        "Distributed-Tiled": "#d62728",
        "Naive-Standard": "#2ca02c",
        "Naive-Tiled": "#9467bd",
        "Parallel-Standard": "#ff7f0e",
        "Parallel-Tiled": "#8c564b",
    }
    platform_style = {
        "Java":  {"linestyle":"-", "marker":"o"},
        "Python":{"linestyle":"--", "marker":"^"}
    }
    for df, platform in dfs:
        pivot = avg_by(df, ['MemoryMB'], ['Algorithm', 'MatrixSize'])
        for alg in algo_list:
            if alg not in pivot['Algorithm'].unique():
                continue
            vals = pivot[pivot['Algorithm']==alg]
            label=f"{alg.replace('Distributed','Dist.').replace('Parallel','Par.').replace('Naive','Naive')} ({platform})"
            plt.plot(
                vals['MatrixSize'], vals['MemoryMB'],
                label=label,
                color=algo_colors[alg],
                linestyle=platform_style[platform]["linestyle"],
                marker=platform_style[platform]["marker"],
                linewidth=2, markersize=6, alpha=0.9
            )
    plt.xscale('log', base=2)
    plt.xlabel('Matrix size (N x N)')
    plt.ylabel('Peak Memory (MB)')
    plt.title('Memory Usage vs Matrix Size')
    plt.grid(True, ls="--", alpha=0.3)
    plt.legend(loc="upper left", fontsize=9, ncol=2)
    plt.tight_layout()
    plt.savefig(os.path.join(PLOT_DIR, filename), dpi=300)
    plt.close()

def plot_java_vs_python_distributed_time(java_df, python_df, filename):
    plt.figure(figsize=(9, 6))
    colors = {"Distributed-Row":"#2980b9", "Distributed-Tiled":"#e74c3c"}
    markers = {"Java":"o", "Python":"s"}
    ds_java = only_distributed(java_df)
    ds_python = only_distributed(python_df)
    for alg in sorted(set(ds_java["Algorithm"]).intersection(ds_python["Algorithm"])):
        j_vals = avg_by(ds_java[ds_java["Algorithm"]==alg], ["TimeSeconds"], ["MatrixSize"])
        p_vals = avg_by(ds_python[ds_python["Algorithm"]==alg], ["TimeSeconds"], ["MatrixSize"])
        plt.plot(j_vals["MatrixSize"], j_vals["TimeSeconds"], color=colors[alg], marker="o", label=f"{alg.replace('Distributed','Dist.')} (Java)")
        plt.plot(p_vals["MatrixSize"], p_vals["TimeSeconds"], color=colors[alg], marker="s", linestyle="--", label=f"{alg.replace('Distributed','Dist.')} (Python)")
    plt.yscale('log')
    plt.xscale('log', base=2)
    plt.xlabel('Matrix size (N x N)')
    plt.ylabel('Time (s, log scale)')
    plt.title('Distributed: Java vs Python (Time)')
    plt.grid(True, ls='--', alpha=0.3)
    plt.legend(fontsize=10)
    plt.tight_layout()
    plt.savefig(os.path.join(PLOT_DIR, filename), dpi=300)
    plt.close()

def plot_network_overhead(java_df, filename):
    pivot = avg_by(java_df, ['NetworkOverhead_s'], ['Algorithm', 'MatrixSize'])
    distributed_algos = [a for a in pivot['Algorithm'].unique() if "Distributed" in a]
    plt.figure(figsize=(8,6))
    for alg in distributed_algos:
        vals = pivot[pivot['Algorithm']==alg]
        plt.plot(vals['MatrixSize'], vals['NetworkOverhead_s'], marker='o', label=alg.replace('Distributed-','Dist. '), linewidth=2)
    plt.xscale('log', base=2)
    plt.xlabel('Matrix size (N x N)')
    plt.ylabel('Network Overhead (s)')
    plt.title('Network Overhead (Distributed Java)')
    plt.legend(fontsize=8)
    plt.grid(True, ls='--', alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(PLOT_DIR, filename), dpi=300)
    plt.close()

def plot_speedup_efficiency(df, filename_prefix):
    pivot = avg_by(df, ['Speedup', 'Efficiency'], ['Algorithm', 'MatrixSize'])
    algos = [a for a in pivot['Algorithm'].unique()
             if ('Parallel' in a or 'Distributed' in a)]
    plt.figure(figsize=(12, 5))
    ax1 = plt.subplot(1, 2, 1)
    for alg in algos:
        vals = pivot[pivot['Algorithm']==alg]
        ax1.plot(vals['MatrixSize'], vals['Speedup'], marker='o', label=alg.replace('Distributed','Dist.').replace('Parallel','Par.'), linewidth=2)
    ax1.set_xlabel('Matrix size (N x N)')
    ax1.set_ylabel('Speedup')
    ax1.grid(True, alpha=0.3)
    ax1.set_title(f"Speedup vs Naive-Standard ({filename_prefix.capitalize()})")
    ax1.legend(fontsize=8)
    ax1.set_xscale('log', base=2)
    ax2 = plt.subplot(1, 2, 2)
    for alg in algos:
        vals = pivot[pivot['Algorithm']==alg]
        ax2.plot(vals['MatrixSize'], vals['Efficiency'], marker='s', label=alg.replace('Distributed','Dist.').replace('Parallel','Par.'), linewidth=2)
    ax2.set_xlabel('Matrix size (N x N)')
    ax2.set_ylabel('Efficiency')
    ax2.grid(True, alpha=0.3)
    ax2.set_title(f"Efficiency ({filename_prefix.capitalize()})")
    ax2.legend(fontsize=8)
    ax2.set_xscale('log', base=2)
    plt.tight_layout()
    plt.savefig(os.path.join(PLOT_DIR, f"{filename_prefix}_speedup_efficiency.png"),
                dpi=300, bbox_inches='tight')
    plt.close()

def main():
    java = read_benchmark_csv(RESULTS_JAVA, "Java")
    python = read_benchmark_csv(RESULTS_PYTHON, "Python")
    plot_time_vs_size([(java, "Java"), (python, "Python")], "execution_time_vs_size.png")
    plot_memory_vs_size([(java, "Java"), (python, "Python")], "memory_vs_size.png")
    plot_java_vs_python_distributed_time(java, python, "distributed_java_vs_python_time.png")
    plot_network_overhead(java, "network_overhead_java.png")
    plot_speedup_efficiency(python, "python")
    plot_speedup_efficiency(java, "java")
    plot_distributed_bars_double(java, python, metric="TimeSeconds", filename="distributed_time.png", ylabel="Execution Time (s)", 
                                 title_base="Distributed Algorithms: Execution Time (N=previous, N=max)", ylim=(0, 400))
    plot_distributed_bars_double(java, python, metric="MemoryMB", filename="distributed_memory.png", ylabel="Peak Memory (MB)", 
                                 title_base="Distributed Algorithms: Memory Usage (N=previous, N=max)", ylim=(0, 1000))
    print("Generated all required plots in 'plots/'!")

if __name__ == "__main__":
    print("Benchmark plotter started")
    main()
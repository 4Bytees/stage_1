package matrix;

import java.util.Random;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

import com.pabcablan.matrix.BasicMatrixMultiplier;

public class BasicMatrixMultiplierTest {

    private double[][] A;
    private double[][] B;
    private double[][] expected;

    @Before
    public void setUp() {
        A = new double[][] {{1, 2}, {3, 4}};
        B = new double[][] {{5, 6}, {7, 8}};
        expected = new double[][] {{19, 22}, {43, 50}};
    }

    @Test
    public void testMultiplyStandard() {
        double[][] result = BasicMatrixMultiplier.multiply(A, B);
        assertMatrixEquals(expected, result, 1e-10);
    }

    @Test
    public void testMultiplyTiledVariousBlockSizes() {
        int[] blockSizes = {1, 2, 4, 32};
        for (int blockSize : blockSizes) {
            double[][] result = BasicMatrixMultiplier.multiplyTiled(A, B, blockSize);
            assertMatrixEquals(expected, result, 1e-10);
        }
    }

    @Test
    public void testAlgorithmsEquivalenceRandom() {
        int n = 8;
        double[][] matrixA = randomMatrix(n, n);
        double[][] matrixB = randomMatrix(n, n);

        double[][] C_std = BasicMatrixMultiplier.multiply(matrixA, matrixB);
        double[][] C_tiled = BasicMatrixMultiplier.multiplyTiled(matrixA, matrixB, 2);

        assertMatrixEquals(C_std, C_tiled, 1e-8);
    }

    @Test
    public void testRandomShape() {
        int size = 10;
        double[][] matrixA = randomMatrix(size, size);
        double[][] matrixB = randomMatrix(size, size);

        double[][] C = BasicMatrixMultiplier.multiply(matrixA, matrixB);

        assertEquals(size, C.length);
        assertEquals(size, C[0].length);
    }

    private static double[][] randomMatrix(int n, int m) {
        Random r = new Random();
        double[][] mat = new double[n][m];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                mat[i][j] = r.nextDouble();
        return mat;
    }

    private void assertMatrixEquals(double[][] expected, double[][] actual, double delta) {
        assertEquals(expected.length, actual.length);
        for (int i = 0; i < expected.length; i++) {
            assertEquals(expected[i].length, actual[i].length);
            for (int j = 0; j < expected[i].length; j++) {
                assertEquals(expected[i][j], actual[i][j], delta);
            }
        }
    }
}
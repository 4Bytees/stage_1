package com.pabcablan.benchmarking;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import com.hazelcast.core.HazelcastInstance;
import com.pabcablan.matrix.BasicMatrixMultiplier;
import com.pabcablan.matrix.DistributedMatrixMultiplier;
import com.pabcablan.matrix.ParallelMatrixMultiplier;
import com.pabcablan.model.BenchmarkCase;
import com.pabcablan.util.MatrixGenerator;

import oshi.SystemInfo;
import oshi.software.os.OSProcess;
import oshi.software.os.OperatingSystem;

public class Benchmark {

    public static void run(HazelcastInstance hazelcast, String outputPath) {
        int[] sizes = {32, 64, 128, 256, 512, 1024, 2048};
        int runs = 3;
        int threads = 4;
        int blockSize = 128;
        int nodes = (hazelcast != null) ? hazelcast.getCluster().getMembers().size() : 1;

        new File(outputPath).getParentFile().mkdirs();
        System.out.println("\n[INFO] Benchmarking in progress...");

        try (PrintWriter csv = new PrintWriter(new FileWriter(outputPath))) {
            csv.println("Algorithm,MatrixSize,Run,NodesUsed,Threads,BlockSize,TimeSeconds,MemoryMB,Speedup,Efficiency,NetworkOverhead_s,DataTransferred_MB,TransferRate_MBps");

            for (int size : sizes) {
                System.out.printf("%n[INFO] === Benchmark for size %dx%d ===%n", size, size);

                for (int run = 1; run <= runs; run++) {
                    System.out.printf("[INFO]  Run %d/%d...%n", run, runs);

                    final double[][] A = MatrixGenerator.generate(size, size);
                    final double[][] B = MatrixGenerator.generate(size, size);
                    final double dataMB = (size * size * 8.0) / (1024 * 1024);

                    List<BenchmarkCase> benchCases;
                    if (size == 2048) {
                        // Exclude Distributed-Row for 2048: fill NaN in CSV for that algorithm
                        benchCases = Arrays.asList(
                            new BenchmarkCase("Naive-Standard", () -> {double[][] result = BasicMatrixMultiplier.multiply(A, B); result = null;}, 1, 0),
                            new BenchmarkCase("Naive-Tiled", () -> {double[][] result = BasicMatrixMultiplier.multiplyTiled(A, B, blockSize); result = null;}, 1, blockSize),
                            new BenchmarkCase("Parallel-Standard", () -> {double[][] result = ParallelMatrixMultiplier.multiply(A, B, threads); result = null;}, threads, 0),
                            new BenchmarkCase("Parallel-Tiled", () -> {double[][] result = ParallelMatrixMultiplier.multiplyTiled(A, B, threads, blockSize); result = null;}, threads, blockSize),
                            // Distributed-Row will be handled below (NaN entry)
                            new BenchmarkCase("Distributed-Tiled", () -> {double[][] result = new DistributedMatrixMultiplier(hazelcast, blockSize).multiply(A, B); result = null;}, nodes, blockSize)
                        );
                    } else {
                        benchCases = Arrays.asList(
                            new BenchmarkCase("Naive-Standard", () -> {double[][] result = BasicMatrixMultiplier.multiply(A, B); result = null;}, 1, 0),
                            new BenchmarkCase("Naive-Tiled", () -> {double[][] result = BasicMatrixMultiplier.multiplyTiled(A, B, blockSize); result = null;}, 1, blockSize),
                            new BenchmarkCase("Parallel-Standard", () -> {double[][] result = ParallelMatrixMultiplier.multiply(A, B, threads); result = null;}, threads, 0),
                            new BenchmarkCase("Parallel-Tiled", () -> {double[][] result = ParallelMatrixMultiplier.multiplyTiled(A, B, threads, blockSize); result = null;}, threads, blockSize),
                            new BenchmarkCase("Distributed-Row", () -> {double[][] result = new DistributedMatrixMultiplier(hazelcast, blockSize).multiplyRowWise(A, B); result = null;}, nodes, 0),
                            new BenchmarkCase("Distributed-Tiled", () -> {double[][] result = new DistributedMatrixMultiplier(hazelcast, blockSize).multiply(A, B); result = null;}, nodes, blockSize)
                        );
                    }

                    double naiveTime = -1, parallelTime = -1;
                    double[] times = new double[benchCases.size() + (size == 2048 ? 1 : 0)];
                    double[] mems = new double[benchCases.size() + (size == 2048 ? 1 : 0)];
                    String[] algNames = new String[benchCases.size() + (size == 2048 ? 1 : 0)];
                    int[] nths = new int[benchCases.size() + (size == 2048 ? 1 : 0)];
                    int[] blockSizes = new int[benchCases.size() + (size == 2048 ? 1 : 0)];
                    boolean[] isDistributedRow = new boolean[benchCases.size() + (size == 2048 ? 1 : 0)];

                    int cur = 0;

                    if (size == 2048) {
                        algNames[cur] = "Distributed-Row";
                        nths[cur] = nodes;
                        blockSizes[cur] = 0;
                        times[cur] = Double.NaN;
                        mems[cur] = Double.NaN;
                        isDistributedRow[cur] = true;
                        cur++;
                    }

                    for (int i = 0; i < benchCases.size(); i++, cur++) {
                        BenchmarkCase bench = benchCases.get(i);
                        String algName = bench.algName;
                        Runnable algFunc = bench.func;
                        int nth = bench.threads;
                        int myBlock = bench.blockSize;

                        algNames[cur] = algName;
                        nths[cur] = nth;
                        blockSizes[cur] = myBlock;
                        isDistributedRow[cur] = algName.equals("Distributed-Row");

                        if (size == 2048 && algName.equals("Distributed-Row")) {
                            times[cur] = Double.NaN;
                            mems[cur] = Double.NaN;
                            continue;
                        }

                        System.out.printf("  [INFO]     Algorithm: %16s | Threads: %d | BlockSize: %d%n", algName, nth, myBlock);

                        System.gc();
                        double memBefore = getProcessMemoryMB();

                        double elapsed = Double.NaN;
                        double maxMem = Double.NaN;

                        long t0 = System.nanoTime();
                        try {
                            algFunc.run();
                            System.gc();
                            double memAfter = getProcessMemoryMB();
                            elapsed = (System.nanoTime() - t0) / 1e9;
                            maxMem = Math.max(memBefore, memAfter);
                            System.out.printf("  [RESULT]   %16s | Time: %.4fs | Mem: %.2fMB%n", algName, elapsed, maxMem);
                        } catch (Exception ex) {
                            System.out.printf("  [FAIL]     %16s | Exception: %s%n", algName, ex.getClass().getSimpleName());
                            elapsed = Double.NaN;
                            maxMem = Double.NaN;
                        }

                        times[cur] = elapsed;
                        mems[cur] = maxMem;

                        if (algName.equals("Naive-Standard") && !Double.isNaN(elapsed)) naiveTime = elapsed;
                        if (algName.equals("Parallel-Standard") && !Double.isNaN(elapsed)) parallelTime = elapsed;
                    }

                    cur = 0;
                    int totalCases = benchCases.size() + (size == 2048 ? 1 : 0);
                    for (int i = 0; i < totalCases; i++) {
                        String algName = algNames[i];
                        int nth = nths[i];
                        int myBlock = blockSizes[i];
                        double time = times[i];
                        double maxMem = mems[i];

                        double speedup = (naiveTime > 0 && time > 0 && !Double.isNaN(time)) ? naiveTime / time : Double.NaN;
                        double efficiency = 0;
                        if (algName.startsWith("Parallel")) {
                            efficiency = (nth > 0 && !Double.isNaN(speedup)) ? speedup / nth : Double.NaN;
                        } else if (algName.startsWith("Distributed")) {
                            efficiency = (nodes > 0 && !Double.isNaN(speedup)) ? speedup / nodes : Double.NaN;
                        } else {
                            efficiency = Double.NaN;
                        }
                        double netOverhead = (algName.startsWith("Distributed") && parallelTime > 0 && !Double.isNaN(time)) ? (time - parallelTime) : Double.NaN;
                        double dataTransferred = algName.startsWith("Distributed") ? dataMB : Double.NaN;
                        double transferRate = (algName.startsWith("Distributed") && !Double.isNaN(time) && time > 0) ? dataMB / time : Double.NaN;

                        boolean nanRow = (size == 2048) && algName.equals("Distributed-Row");
                        csv.printf("%s,%d,%d,%d,%d,%d,%.5f,%.2f,%.5f,%.5f,%.5f,%.2f,%.2f%n",
                            algName, size, run, nodes, nth, myBlock,
                            nanRow ? Double.NaN : time,
                            nanRow ? Double.NaN : maxMem,
                            nanRow ? Double.NaN : speedup,
                            nanRow ? Double.NaN : efficiency,
                            nanRow ? Double.NaN : netOverhead,
                            nanRow ? Double.NaN : dataTransferred,
                            nanRow ? Double.NaN : transferRate
                        );
                    }
                }
                System.out.printf("[INFO] === Finished size %d, all runs ===%n", size);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("\n[INFO] Benchmark finished. Results:  " + outputPath);
    }

    private static double getProcessMemoryMB() {
        SystemInfo si = new SystemInfo();
        OperatingSystem os = si.getOperatingSystem();
        int pid = os.getProcessId();
        OSProcess proc = os.getProcess(pid);
        if (proc == null) return -1;
        long rss = proc.getResidentSetSize();
        return rss / (1024.0 * 1024.0);
    }
}
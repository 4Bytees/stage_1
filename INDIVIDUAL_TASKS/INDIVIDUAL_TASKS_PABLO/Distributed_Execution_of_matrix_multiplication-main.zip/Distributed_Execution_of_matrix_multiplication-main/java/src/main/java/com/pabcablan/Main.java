package com.pabcablan;

import com.hazelcast.core.HazelcastInstance;
import com.pabcablan.benchmarking.Benchmark;
import com.pabcablan.config.HazelcastConfig;

public class Main {
    public static void main(String[] args) {
        System.out.println("Starting Hazelcast Node...");
        HazelcastInstance hazelcast = HazelcastConfig.initHazelcast("MatrixCluster");
        int nodes = hazelcast.getCluster().getMembers().size();

        System.out.println("Cluster ready: " + nodes + " nodes");

        boolean isMaster = hazelcast.getCluster().getMembers().iterator().next()
                .equals(hazelcast.getCluster().getLocalMember());

        if (isMaster) {
            System.out.println("MASTER node. Running benchmark...");
            String output = args.length > 0 ? args[0] : "./results/distributed_benchmark_java.csv";
            Benchmark.run(hazelcast, output);
        } else {
            System.out.println("WORKER node. Waiting for tasks...");
        }

        try { Thread.currentThread().join(); } catch (InterruptedException e) {}
    }
}
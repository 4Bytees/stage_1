import numpy as np
from numba import jit, prange


class MatrixNumba:

    def __init__(self, data):
        if isinstance(data, np.ndarray):
            self.data = data.astype(np.float64)
        else:
            self.data = np.array(data, dtype=np.float64)
        self.shape = self.data.shape

    @classmethod
    def random(cls, n: int):
        return cls(np.random.rand(n, n).astype(np.float64))

    def multiply_standard(self, other):
        C = _numba_standard(self.data, other.data)
        return MatrixNumba(C)

    def multiply_standard_parallel(self, other):
        C = _numba_standard_parallel(self.data, other.data)
        return MatrixNumba(C)

    def multiply_tiled(self, other, block_size = 32):
        C = _numba_tiled(self.data, other.data, block_size)
        return MatrixNumba(C)

    def multiply_tiled_parallel(self, other, block_size = 32):
        C = _numba_tiled_parallel(self.data, other.data, block_size)
        return MatrixNumba(C)


@jit(nopython=True)
def _numba_standard(A, B):
    n = A.shape[0]
    C = np.zeros((n, n), dtype=np.float64)

    for i in range(n):
        for j in range(n):
            s = 0.0
            for k in range(n):
                s += A[i, k] * B[k, j]
            C[i, j] = s

    return C


@jit(nopython=True, parallel=True)
def _numba_standard_parallel(A, B):
    n = A.shape[0]
    C = np.zeros((n, n), dtype=np.float64)

    for i in prange(n):
        for j in range(n):
            s = 0.0
            for k in range(n):
                s += A[i, k] * B[k, j]
            C[i, j] = s

    return C


@jit(nopython=True)
def _numba_tiled(A, B, block_size):
    n = A.shape[0]
    C = np.zeros((n, n), dtype=np.float64)

    for i_block in range(0, n, block_size):
        for j_block in range(0, n, block_size):
            for k_block in range(0, n, block_size):

                i_limit = min(i_block + block_size, n)
                j_limit = min(j_block + block_size, n)
                k_limit = min(k_block + block_size, n)

                for i in range(i_block, i_limit):
                    for k in range(k_block, k_limit):
                        aik = A[i, k]
                        for j in range(j_block, j_limit):
                            C[i, j] += aik * B[k, j]

    return C


@jit(nopython=True, parallel=True)
def _numba_tiled_parallel(A, B, block_size):
    n = A.shape[0]
    C = np.zeros((n, n), dtype=np.float64)

    num_blocks_i = (n + block_size - 1) // block_size

    for bi in prange(num_blocks_i):
        i_block = bi * block_size
        i_limit = min(i_block + block_size, n)

        for j_block in range(0, n, block_size):
            j_limit = min(j_block + block_size, n)

            for k_block in range(0, n, block_size):
                k_limit = min(k_block + block_size, n)

                for i in range(i_block, i_limit):
                    for k in range(k_block, k_limit):
                        aik = A[i, k]
                        for j in range(j_block, j_limit):
                            C[i, j] += aik * B[k, j]

    return C

import numpy as np
from multiprocessing import Pool, cpu_count
from functools import partial


class MatrixMultiprocessing:

    def __init__(self, data):
        if isinstance(data, np.ndarray):
            self.data = data.astype(np.float64)
        else:
            self.data = np.array(data, dtype=np.float64)
        self.shape = self.data.shape

    @classmethod
    def random(cls, n):
        return cls(np.random.rand(n, n).astype(np.float64))

    def multiply_standard(self, other):
        n = self.shape[0]
        num_processes = min(cpu_count(), n)
        
        with Pool(num_processes) as pool:
            func = partial(_compute_row_standard, self.data, other.data)
            rows = pool.map(func, range(n))
        
        C = np.array(rows)
        return MatrixMultiprocessing(C)

    def multiply_tiled(self, other, block_size=32):
        n = self.shape[0]
        num_blocks = (n + block_size - 1) // block_size
        num_processes = min(cpu_count(), num_blocks)
        
        with Pool(num_processes) as pool:
            func = partial(_compute_block_tiled, self.data, other.data, block_size)
            blocks = pool.map(func, range(num_blocks))
        
        C = np.zeros((n, n), dtype=np.float64)
        for i_block, block_rows in enumerate(blocks):
            i_start = i_block * block_size
            i_end = min(i_start + block_size, n)
            C[i_start:i_end] = block_rows[:i_end-i_start]
        
        return MatrixMultiprocessing(C)


def _compute_row_standard(A, B, i):
    n = A.shape[0]
    row = np.zeros(n, dtype=np.float64)
    for j in range(n):
        s = 0.0
        for k in range(n):
            s += A[i, k] * B[k, j]
        row[j] = s
    return row


def _compute_block_tiled(A, B, block_size, bi):
    n = A.shape[0]
    i_block = bi * block_size
    i_limit = min(i_block + block_size, n)
    block_rows = np.zeros((i_limit - i_block, n), dtype=np.float64)
    
    for i in range(i_block, i_limit):
        for j_block in range(0, n, block_size):
            j_limit = min(j_block + block_size, n)
            for k_block in range(0, n, block_size):
                k_limit = min(k_block + block_size, n)
                
                for j in range(j_block, j_limit):
                    s = 0.0
                    for k in range(k_block, k_limit):
                        s += A[i, k] * B[k, j]
                    block_rows[i - i_block, j] += s
    
    return block_rows
